import { useEffect, useRef, useState } from 'react'
import {
  AlertCircle,
  Baby,
  Camera,
  Droplets,
  Lightbulb,
  Moon,
  RefreshCw,
  Thermometer,
  Upload,
  Video,
  Wifi,
  WifiOff,
} from 'lucide-react'

import Card from '../components/common/Card'
import Header from '../components/common/Header'
import StatusBadge from '../components/common/StatusBadge'
import { getDashboard } from '../api/dashboardApi'
import {
  getInferenceResult,
  getInferenceStatus,
  requestMultimodalInference,
} from '../api/inferenceApi'
import {
  buildLiveWebSocketUrl,
  getLiveSessions,
} from '../api/liveApi'
import { preprocessVideoForInference } from '../utils/videoPreprocess'

const peerConfig = {
  iceServers: [
    { urls: 'stun:stun.l.google.com:19302' },
  ],
}

function HomePage() {
  const fileInputRef = useRef(null)
  const remoteVideoRef = useRef(null)
  const socketRef = useRef(null)
  const peerRef = useRef(null)

  const [dashboardData, setDashboardData] = useState(null)
  const [initialLoading, setInitialLoading] = useState(true)
  const [dashboardError, setDashboardError] = useState(null)
  const [refreshingDashboard, setRefreshingDashboard] = useState(false)

  const [uploading, setUploading] = useState(false)
  const [uploadMessage, setUploadMessage] = useState('')
  const [uploadError, setUploadError] = useState('')
  const [analysisResult, setAnalysisResult] = useState(null)

  const [liveSessions, setLiveSessions] = useState([])
  const [selectedSession, setSelectedSession] = useState(null)
  const [liveStatus, setLiveStatus] = useState('?쇱씠釉??몄뀡 ?湲?以?)
  const [liveError, setLiveError] = useState('')
  const [liveConnecting, setLiveConnecting] = useState(false)

  useEffect(() => {
    loadDashboard({ initial: true })
    loadLiveSessions()

    const sessionTimer = window.setInterval(() => {
      loadLiveSessions()
    }, 5000)

    return () => {
      window.clearInterval(sessionTimer)
      stopLiveViewer()
    }
  }, [])

  useEffect(() => {
    if (!selectedSession) {
      return undefined
    }

    loadDashboard({ silent: true })

    const dashboardTimer = window.setInterval(() => {
      loadDashboard({ silent: true })
    }, 5000)

    return () => {
      window.clearInterval(dashboardTimer)
    }
  }, [selectedSession])

  async function loadDashboard(options = {}) {
    try {
      if (options.initial) {
        setInitialLoading(true)
      } else if (!options.silent) {
        setRefreshingDashboard(true)
      }

      const result = await getDashboard()
      setDashboardData(result)
      setDashboardError(null)
    } catch (err) {
      setDashboardError(err)
    } finally {
      setInitialLoading(false)
      setRefreshingDashboard(false)
    }
  }

  async function loadLiveSessions() {
    try {
      const sessions = await getLiveSessions()
      setLiveSessions(sessions || [])
    } catch {
      // ???붾㈃ ?꾩껜 ?ㅻ쪟濡?泥섎━?섏? ?딆쓬
    }
  }

  async function connectToLiveSession(session) {
    try {
      stopLiveViewer(false)

      setLiveError('')
      setLiveConnecting(true)
      setSelectedSession(session)
      setLiveStatus('?쇱씠釉??몄뀡???곌껐?섎뒗 以묒엯?덈떎...')

      const peer = new RTCPeerConnection(peerConfig)
      peerRef.current = peer

      peer.ontrack = (event) => {
        const [stream] = event.streams
        const video = remoteVideoRef.current

        if (video && stream) {
          video.srcObject = stream
          video.muted = true
          video.playsInline = true

          video.play().catch(() => {
            setLiveStatus('?곸긽 ?ㅽ듃由쇱? ?섏떊?덉?留??먮룞 ?ъ깮??李⑤떒?섏뿀?듬땲?? ?붾㈃????踰??곗튂?댁＜?몄슂.')
          })
        }

        setLiveStatus('?ㅼ떆媛??곸긽 ?ㅽ듃由??섏떊 以묒엯?덈떎.')
      }

      peer.onicecandidate = (event) => {
        if (event.candidate && socketRef.current?.readyState === WebSocket.OPEN) {
          socketRef.current.send(JSON.stringify({
            type: 'candidate',
            candidate: event.candidate,
          }))
        }
      }

      peer.onconnectionstatechange = () => {
        if (peer.connectionState === 'connected') {
          setLiveStatus('P2P ?쇱씠釉??곌껐 ?꾨즺')
        }

        if (peer.connectionState === 'failed') {
          setLiveStatus('P2P ?곌껐 ?ㅽ뙣. TURN ?쒕쾭媛 ?꾩슂?????덉뒿?덈떎.')
        }

        if (peer.connectionState === 'disconnected') {
          setLiveStatus('?쇱씠釉??곌껐???쇱떆?곸쑝濡??딄꼈?듬땲??')
        }

        if (peer.connectionState === 'closed') {
          setLiveStatus('?쇱씠釉??곌껐??醫낅즺?섏뿀?듬땲??')
        }
      }

      const wsUrl = buildLiveWebSocketUrl(session.sessionId, 'viewer')
      const socket = new WebSocket(wsUrl)
      socketRef.current = socket

      socket.onopen = () => {
        setLiveConnecting(false)
        setLiveStatus('?덉틺???곌껐 ?붿껌??蹂대깉?듬땲??')
        socket.send(JSON.stringify({ type: 'viewer-ready' }))
      }

      socket.onmessage = async (event) => {
        const message = JSON.parse(event.data)

        if (message.type === 'offer') {
          await peer.setRemoteDescription(new RTCSessionDescription(message.offer))

          const answer = await peer.createAnswer()
          await peer.setLocalDescription(answer)

          socket.send(JSON.stringify({
            type: 'answer',
            answer,
          }))

          setLiveStatus('?쇱씠釉??묐떟???꾩넚?덉뒿?덈떎.')
          return
        }

        if (message.type === 'candidate') {
          if (message.candidate) {
            await peer.addIceCandidate(new RTCIceCandidate(message.candidate))
          }
          return
        }

        if (message.type === 'host-disconnected') {
          setLiveStatus('?덉틺 ?곌껐??醫낅즺?섏뿀?듬땲??')
          stopLiveViewer(false)
        }
      }

      socket.onerror = () => {
        setLiveConnecting(false)
        setLiveError('WebSocket ?곌껐 以??ㅻ쪟媛 諛쒖깮?덉뒿?덈떎.')
        setLiveStatus('?쇱씠釉??곌껐 ?ㅽ뙣')
      }

      socket.onclose = () => {
        setLiveConnecting(false)
      }
    } catch (err) {
      setLiveConnecting(false)
      setLiveError(err.message || '?쇱씠釉??곌껐 以??ㅻ쪟媛 諛쒖깮?덉뒿?덈떎.')
      setLiveStatus('?쇱씠釉??곌껐 ?ㅽ뙣')
    }
  }

  function stopLiveViewer(clearSession = true) {
    if (peerRef.current) {
      peerRef.current.close()
      peerRef.current = null
    }

    if (socketRef.current) {
      socketRef.current.close()
      socketRef.current = null
    }

    if (remoteVideoRef.current) {
      remoteVideoRef.current.srcObject = null
    }

    if (clearSession) {
      setSelectedSession(null)
      setLiveStatus('?쇱씠釉??몄뀡 ?湲?以?)
      setLiveError('')
      loadDashboard({ silent: true })
    }
  }

  async function handleVideoSelected(event) {
    const file = event.target.files?.[0]

    if (!file) {
      return
    }

    try {
      setUploading(true)
      setUploadMessage('?곸긽 ?꾩쿂由щ? ?쒖옉?⑸땲??..')
      setUploadError('')
      setAnalysisResult(null)

      const preprocessed = await preprocessVideoForInference(file, {
        framesPerSecond: 1,
        maxFrames: 20,
        maxWidth: 640,
        onProgress: setUploadMessage,
      })

      if (preprocessed.frameFiles.length === 0 && !preprocessed.audioFile) {
        throw new Error('遺꾩꽍???꾨젅???먮뒗 ?ㅻ뵒?ㅻ? 異붿텧?섏? 紐삵뻽?듬땲??')
      }

      const audioStatus = preprocessed.audioFile
        ? '?ㅻ뵒??異붿텧 ?꾨즺'
        : '?ㅻ뵒??異붿텧 ?ㅽ뙣. ?꾨젅?꾨쭔 ?꾩넚?⑸땲??'

      setUploadMessage(
        '?꾨젅??' +
          preprocessed.frameFiles.length +
          '媛?異붿텧 ?꾨즺. ' +
          audioStatus +
          ' ?쒕쾭??遺꾩꽍 ?묒뾽???깅줉?섎뒗 以묒엯?덈떎...'
      )

      const queued = await requestMultimodalInference({
        audioFile: preprocessed.audioFile,
        frameFiles: preprocessed.frameFiles,
        capturedAt: new Date().toISOString(),
        frameRate: preprocessed.frameRate,
        durationSeconds: preprocessed.durationSeconds,
      })

      const requestId = queued.requestId

      if (!requestId) {
        throw new Error('?쒕쾭 ?묐떟??requestId媛 ?놁뒿?덈떎.')
      }

      setUploadMessage('遺꾩꽍 ?묒뾽???깅줉?섏뿀?듬땲?? ?묒뾽 泥섎━ ?곹깭瑜??뺤씤?섎뒗 以묒엯?덈떎...')

      const completedResult = await waitForInferenceCompleted(requestId, {
        onProgress: setUploadMessage,
      })

      setAnalysisResult({
        ...completedResult.result,
        requestId,
        saved: completedResult.saved,
      })

      setUploadMessage('?곸긽 遺꾩꽍???꾨즺?섏뿀?듬땲??')
      await loadDashboard({ silent: true })
    } catch (err) {
      setUploadError(err.message || '?곸긽 遺꾩꽍 ?붿껌 以??ㅻ쪟媛 諛쒖깮?덉뒿?덈떎.')
      setUploadMessage('')
    } finally {
      setUploading(false)

      if (fileInputRef.current) {
        fileInputRef.current.value = ''
      }
    }
  }

  const currentEmotion = dashboardData?.currentEmotion
  const environment = dashboardData?.environment
  const cameras = dashboardData?.cameras
  const alerts = dashboardData?.alerts || []
  const currentPredictions = getTopPredictions(currentEmotion)

  return (
    <main className='px-5 py-6'>
      <Header />

      {initialLoading && (
        <Card>
          <p className='text-sm text-slate-300'>??쒕낫???뺣낫瑜?遺덈윭?ㅻ뒗 以묒엯?덈떎...</p>
        </Card>
      )}

      {dashboardError && !dashboardData && (
        <Card>
          <p className='font-semibold text-rose-300'>?곗씠?곕? 遺덈윭?ㅼ? 紐삵뻽?듬땲??</p>
          <p className='mt-2 text-sm text-slate-400'>{dashboardError.message}</p>
        </Card>
      )}

      {!initialLoading && dashboardData && (
        <>
          <section className='mb-5 overflow-hidden rounded-[32px] border border-slate-700/70 bg-slate-900 shadow-card'>
            <div className='relative flex h-64 items-center justify-center bg-gradient-to-br from-slate-800 via-slate-900 to-indigo-950'>
              <video
                ref={remoteVideoRef}
                autoPlay
                playsInline
                muted
                controls={false}
                className={selectedSession ? 'h-full w-full object-cover' : 'hidden'}
              />

              {!selectedSession && (
                <div className='text-center'>
                  <div className='mx-auto mb-3 flex h-16 w-16 items-center justify-center rounded-full bg-white/10'>
                    <Camera size={32} className='text-blue-200' />
                  </div>
                  <p className='text-lg font-semibold'>?꾧린 諛?移대찓??/p>
                  <p className='mt-1 text-sm text-slate-400'>
                    ?깅줉 移대찓??{cameras?.totalCount || 0}? 쨌 ?⑤씪???몄뀡 {liveSessions.length}媛?
                  </p>
                </div>
              )}

              <div className='absolute left-4 top-4'>
                <StatusBadge type={selectedSession ? 'normal' : liveSessions.length > 0 ? 'normal' : 'warning'}>
                  {selectedSession ? 'LIVE' : liveSessions.length > 0 ? 'READY' : 'OFFLINE'}
                </StatusBadge>
              </div>

              {refreshingDashboard && selectedSession && (
                <div className='absolute right-4 top-4 rounded-full bg-black/50 px-3 py-1 text-[11px] text-slate-200'>
                  遺꾩꽍 寃곌낵 媛깆떊 以?
                </div>
              )}

              {selectedSession && (
                <div className='absolute bottom-4 left-4 right-4 rounded-2xl bg-black/55 p-3 text-xs text-slate-100'>
                  {liveStatus}
                </div>
              )}
            </div>

            <div className='p-5'>
              <div className='mb-4 flex items-center justify-between'>
                <div>
                  <p className='text-sm text-slate-400'>?꾧린 諛?移대찓??/p>
                  <h2 className='mt-1 text-2xl font-bold'>
                    {selectedSession ? '?ㅼ떆媛?紐⑤땲?곕쭅 以? : '?쇱씠釉??쇰뱶 ?湲?}
                  </h2>
                </div>

                <div className='flex h-14 w-14 items-center justify-center rounded-2xl bg-indigo-400/15 text-indigo-200'>
                  <Moon size={28} />
                </div>
              </div>

              {liveError && (
                <p className='mb-4 rounded-2xl bg-rose-400/10 p-3 text-sm text-rose-300'>
                  {liveError}
                </p>
              )}

              {!selectedSession && (
                <div className='mb-4 rounded-2xl bg-slate-950/40 p-4'>
                  <div className='mb-3 flex items-center justify-between'>
                    <p className='text-sm font-semibold text-blue-200'>?⑤씪???쇱씠釉??몄뀡</p>
                    <button
                      type='button'
                      onClick={loadLiveSessions}
                      className='rounded-xl bg-slate-800 p-2 text-slate-300'
                    >
                      <RefreshCw size={16} />
                    </button>
                  </div>

                  {liveSessions.length === 0 ? (
                    <p className='text-xs leading-5 text-slate-400'>
                      ?꾩옱 ?곌껐 媛?ν븳 ?덉틺 ?몄뀡???놁뒿?덈떎. 怨듦린怨??대??곗뿉???덉틺 紐⑤뱶瑜?癒쇱? ?쒖옉?섏꽭??
                    </p>
                  ) : (
                    <div className='space-y-2'>
                      {liveSessions.slice(0, 3).map((session) => (
                        <button
                          key={session.sessionId}
                          type='button'
                          disabled={liveConnecting}
                          onClick={() => connectToLiveSession(session)}
                          className='flex w-full items-center justify-between rounded-2xl bg-slate-800/80 p-3 text-left transition hover:bg-slate-800 disabled:opacity-60'
                        >
                          <div>
                            <p className='text-sm font-semibold text-white'>
                              {session.cameraName || '?대????덉틺'}
                            </p>
                            <p className='mt-1 text-xs text-slate-500'>
                              {session.status} 쨌 {session.sessionId}
                            </p>
                          </div>
                          <Wifi size={18} className='text-emerald-300' />
                        </button>
                      ))}
                    </div>
                  )}
                </div>
              )}

              {selectedSession && (
                <button
                  type='button'
                  onClick={() => stopLiveViewer(true)}
                  className='mb-4 flex w-full items-center justify-center gap-2 rounded-2xl bg-slate-800 py-3 text-sm font-bold text-slate-200'
                >
                  <WifiOff size={18} />
                  ?쇱씠釉??곌껐 醫낅즺
                </button>
              )}

              <div className='rounded-[28px] bg-slate-950/50 p-5'>
                <div className='mb-4 flex items-center gap-3'>
                  <div className='flex h-11 w-11 items-center justify-center rounded-full bg-blue-400/15 text-blue-200'>
                    <Baby size={24} />
                  </div>
                  <div>
                    <p className='text-xs font-semibold text-blue-200'>理쒓렐 AI 遺꾩꽍 寃곌낵</p>
                    <h3 className='text-lg font-bold text-white'>?꾩옱 ?꾧린媛 ?곕뒗 ?댁쑀</h3>
                  </div>
                </div>

                {currentPredictions.length === 0 ? (
                  <p className='text-sm leading-6 text-slate-400'>
                    ?꾩쭅 遺꾩꽍??媛먯젙 ?곗씠?곌? ?놁뒿?덈떎. ?덉틺 ?ㅼ떆媛?遺꾩꽍 ?먮뒗 ?곸긽 ?낅줈??遺꾩꽍???ㅽ뻾?섏꽭??
                  </p>
                ) : (
                  <div className='grid grid-cols-2 gap-3'>
                    {currentPredictions.map((item, index) => (
                      <div
                        key={item.emotion + index}
                        className='rounded-3xl border border-slate-700/70 bg-slate-900/80 p-4'
                      >
                        <div className='mb-3 flex items-center justify-between'>
                          <div className='flex h-12 w-12 items-center justify-center rounded-2xl bg-white/10 text-2xl'>
                            {getEmotionIcon(item.need || item.emotion)}
                          </div>
                          <span className='rounded-full bg-blue-400/10 px-2 py-1 text-[11px] font-semibold text-blue-200'>
                            TOP {index + 1}
                          </span>
                        </div>

                        <p className='text-sm font-bold text-blue-200'>
                          {toUserFriendlyEmotion(item.emotion)}
                        </p>

                        <p className='mt-1 text-3xl font-light text-white'>
                          {Math.round((item.confidence || 0) * 100)}
                          <span className='ml-1 text-base text-slate-400'>%</span>
                        </p>
                      </div>
                    ))}
                  </div>
                )}

                <p className='mt-4 text-xs leading-5 text-slate-400'>
                  ?덉틺?먯꽌 5珥??⑥쐞 遺꾩꽍???꾨즺?섎㈃ 理쒖떊 ?곹깭 ?꾨낫 2媛쒓? ?먮룞?쇰줈 媛깆떊?⑸땲??
                </p>
              </div>
            </div>
          </section>

          <Card className='mb-5 border-blue-400/30 bg-gradient-to-br from-slate-900 to-blue-950/60'>
            <div className='flex items-start gap-4'>
              <div className='flex h-14 w-14 shrink-0 items-center justify-center rounded-2xl bg-blue-400/15 text-blue-200'>
                <Video size={28} />
              </div>

              <div className='min-w-0 flex-1'>
                <p className='text-sm font-semibold text-blue-200'>?곸긽 ?낅줈??遺꾩꽍</p>
                <h2 className='mt-1 text-xl font-bold text-white'>
                  ??λ맂 ?곸긽?쇰줈 媛먯젙 ?곹깭 遺꾩꽍
                </h2>
                <p className='mt-2 text-sm leading-6 text-slate-400'>
                  ?곸긽???낅줈?쒗븯硫?釉뚮씪?곗??먯꽌 ?꾨젅?꾧낵 ?ㅻ뵒?ㅻ? 異붿텧???? AI 遺꾩꽍 ?쒕쾭濡??꾩넚?⑸땲??
                </p>
              </div>
            </div>

            <div className='mt-4 rounded-2xl bg-slate-950/40 p-4 text-xs leading-5 text-slate-400'>
              ?꾩옱???꾨줈?좏????④퀎?낅땲?? ?덈뱶濡쒖씠???섍꼍 湲곗??쇰줈 ?곸긽?먯꽌 ?ㅻ뵒?ㅼ? ?꾨젅?꾩쓣 異붿텧??遺꾩꽍???붿껌?⑸땲??
            </div>

            <input
              ref={fileInputRef}
              type='file'
              accept='video/*'
              className='hidden'
              onChange={handleVideoSelected}
            />

            <button
              type='button'
              disabled={uploading}
              onClick={() => fileInputRef.current?.click()}
              className='mt-4 flex w-full items-center justify-center gap-2 rounded-2xl bg-blue-500 py-3 text-sm font-bold text-white transition hover:bg-blue-400 disabled:cursor-not-allowed disabled:bg-slate-700 disabled:text-slate-400'
            >
              <Upload size={18} />
              {uploading ? '遺꾩꽍 ?붿껌 以?..' : '?곸긽 ?낅줈?쒗븯??遺꾩꽍'}
            </button>

            {uploadMessage && (
              <p className='mt-3 rounded-2xl bg-blue-400/10 p-3 text-sm leading-6 text-blue-100'>
                {uploadMessage}
              </p>
            )}

            {uploadError && (
              <p className='mt-3 rounded-2xl bg-rose-400/10 p-3 text-sm leading-6 text-rose-300'>
                {uploadError}
              </p>
            )}

            {analysisResult && (
              <TopPredictionCard analysisResult={analysisResult} />
            )}
          </Card>

          <div className='mb-5 grid grid-cols-3 gap-3'>
            <Card className='p-4'>
              <Thermometer size={22} className='mb-3 text-rose-300' />
              <p className='text-xs text-slate-400'>?⑤룄</p>
              <p className='mt-1 text-lg font-bold'>
                {environment?.temperature ?? '-'}째C
              </p>
            </Card>

            <Card className='p-4'>
              <Droplets size={22} className='mb-3 text-blue-300' />
              <p className='text-xs text-slate-400'>?듬룄</p>
              <p className='mt-1 text-lg font-bold'>
                {environment?.humidity ?? '-'}%
              </p>
            </Card>

            <Card className='p-4'>
              <Lightbulb size={22} className='mb-3 text-amber-300' />
              <p className='text-xs text-slate-400'>議곕챸</p>
              <p className='mt-1 text-lg font-bold'>
                {environment?.light || '-'}
              </p>
            </Card>
          </div>

          <Card>
            <div className='mb-4 flex items-center justify-between'>
              <h2 className='text-lg font-bold'>理쒓렐 ?뚮┝</h2>
              <AlertCircle size={20} className='text-slate-400' />
            </div>

            {alerts.length === 0 ? (
              <p className='text-sm text-slate-400'>理쒓렐 ?뚮┝???놁뒿?덈떎.</p>
            ) : (
              <div className='space-y-3'>
                {alerts.map((alert) => (
                  <div key={alert.id} className='rounded-2xl bg-slate-800/70 p-4'>
                    <div className='mb-1 flex items-center justify-between'>
                      <p className='font-semibold'>{alert.title}</p>
                      <span className='text-xs text-slate-500'>
                        {formatTime(alert.created_at)}
                      </span>
                    </div>
                    <p className='text-sm leading-5 text-slate-400'>
                      {alert.message}
                    </p>
                  </div>
                ))}
              </div>
            )}
          </Card>
        </>
      )}
    </main>
  )
}

function TopPredictionCard({ analysisResult }) {
  const predictions = getTopPredictions(analysisResult)

  return (
    <div className='mt-4 rounded-[28px] bg-slate-950/50 p-5'>
      <div className='mb-4 flex items-center gap-3'>
        <div className='flex h-11 w-11 items-center justify-center rounded-full bg-blue-400/15 text-blue-200'>
          <Baby size={24} />
        </div>
        <div>
          <p className='text-xs font-semibold text-blue-200'>AI 遺꾩꽍 寃곌낵</p>
          <h3 className='text-lg font-bold text-white'>?꾩옱 ?꾧린媛 ?곕뒗 ?댁쑀</h3>
        </div>
      </div>

      <div className='grid grid-cols-2 gap-3'>
        {predictions.map((item, index) => (
          <div
            key={item.emotion + index}
            className='rounded-3xl border border-slate-700/70 bg-slate-900/80 p-4'
          >
            <div className='mb-3 flex items-center justify-between'>
              <div className='flex h-12 w-12 items-center justify-center rounded-2xl bg-white/10 text-2xl'>
                {getEmotionIcon(item.need || item.emotion)}
              </div>
              <span className='rounded-full bg-blue-400/10 px-2 py-1 text-[11px] font-semibold text-blue-200'>
                TOP {index + 1}
              </span>
            </div>

            <p className='text-sm font-bold text-blue-200'>
              {toUserFriendlyEmotion(item.emotion)}
            </p>

            <p className='mt-1 text-3xl font-light text-white'>
              {Math.round((item.confidence || 0) * 100)}
              <span className='ml-1 text-base text-slate-400'>%</span>
            </p>
          </div>
        ))}
      </div>

      <p className='mt-4 text-xs leading-5 text-slate-400'>
        AI媛 媛?μ꽦???믪? ?곹깭 2媛吏瑜??쒖떆?⑸땲?? 蹂댄샇?먮뒗 ?ㅼ젣 ?곹솴???④퍡 蹂닿퀬 ?먮떒?????덉뒿?덈떎.
      </p>
    </div>
  )
}

function getTopPredictions(result) {
  if (!result) {
    return []
  }

  if (result.topPredictions?.length > 0) {
    return result.topPredictions.slice(0, 2)
  }

  if (result.top_predictions?.length > 0) {
    return result.top_predictions.slice(0, 2)
  }

  return [
    {
      emotion: result.emotion,
      confidence: result.confidence,
      need: result.need,
      message: result.message,
    },
  ]
}

async function waitForInferenceCompleted(requestId, options = {}) {
  const onProgress = options.onProgress || (() => {})
  const maxAttempts = options.maxAttempts || 60
  const intervalMs = options.intervalMs || 2000

  for (let attempt = 0; attempt < maxAttempts; attempt += 1) {
    const status = await getInferenceStatus(requestId)

    if (status.status === 'completed') {
      onProgress('遺꾩꽍???꾨즺?섏뼱 寃곌낵瑜?遺덈윭?ㅻ뒗 以묒엯?덈떎...')
      return getInferenceResult(requestId)
    }

    if (status.status === 'failed') {
      throw new Error(status.message || '遺꾩꽍 ?묒뾽???ㅽ뙣?덉뒿?덈떎.')
    }

    if (status.status === 'processing') {
      onProgress('AI 遺꾩꽍 ?묒뾽??泥섎━ 以묒엯?덈떎...')
    } else {
      onProgress('遺꾩꽍 ?湲곗뿴?먯꽌 ?쒖꽌瑜?湲곕떎由щ뒗 以묒엯?덈떎...')
    }

    await sleep(intervalMs)
  }

  throw new Error('遺꾩꽍 ?묒뾽 ?쒓컙??珥덇낵?섏뿀?듬땲??')
}

function toUserFriendlyEmotion(value) {
  if (!value) return '遺꾩꽍 以?

  const mapping = {
    諛곌퀬?? '諛곌퀬?뚯슂',
    ?좎??? '?좎???,
    ?쇨낀?? '?좎???,
    遺덊렪?? '遺덊렪?댁슂',
    '?덉젙 ?곹깭': '愿쒖갖?꾩슂',
    ?덉젙?곹깭: '愿쒖갖?꾩슂',
  }

  return mapping[value] || value
}

function getEmotionIcon(value) {
  const key = String(value || '')

  if (key.includes('feeding') || key.includes('諛곌퀬')) {
    return '?띁'
  }

  if (key.includes('sleep') || key.includes('??) || key.includes('?쇨낀')) {
    return '?뙔'
  }

  if (key.includes('care') || key.includes('遺덊렪')) {
    return '?뙜截?
  }

  if (key.includes('stable') || key.includes('?덉젙')) {
    return '?삃'
  }

  return '?뫔'
}

function sleep(ms) {
  return new Promise((resolve) => {
    setTimeout(resolve, ms)
  })
}

function formatTime(value) {
  if (!value) return ''

  const date = new Date(value)

  if (Number.isNaN(date.getTime())) {
    return ''
  }

  return date.toLocaleTimeString('ko-KR', {
    timeZone: 'Asia/Seoul',
    hour: '2-digit',
    minute: '2-digit',
  })
}

export default HomePage
