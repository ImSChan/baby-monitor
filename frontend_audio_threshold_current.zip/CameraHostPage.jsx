import { useEffect, useRef, useState } from 'react'
import { Activity, Camera, Radio, Square, Video } from 'lucide-react'

import Card from '../components/common/Card'
import Header from '../components/common/Header'
import { buildLiveWebSocketUrl, createLiveSession } from '../api/liveApi'
import {
  getInferenceResult,
  getInferenceStatus,
  requestMultimodalInference,
} from '../api/inferenceApi'

const peerConfig = {
  iceServers: [
    { urls: 'stun:stun.l.google.com:19302' },
  ],
}

const ANALYSIS_INTERVAL_MS = 5000
const AUDIO_SAMPLE_RATE = 16000

function CameraHostPage() {
  const videoRef = useRef(null)
  const streamRef = useRef(null)
  const socketRef = useRef(null)
  const peerRef = useRef(null)
  const analysisTimerRef = useRef(null)
  const analysisRunningRef = useRef(false)
  const stopRequestedRef = useRef(false)

  const [sessionId, setSessionId] = useState('')
  const [status, setStatus] = useState('idle')
  const [error, setError] = useState('')
  const [isStreaming, setIsStreaming] = useState(false)

  const [analysisEnabled, setAnalysisEnabled] = useState(true)
  const [analysisStatus, setAnalysisStatus] = useState('遺꾩꽍 ?湲?以?)
  const [latestAnalysis, setLatestAnalysis] = useState(null)
  const [analysisCount, setAnalysisCount] = useState(0)

  useEffect(() => {
    return () => {
      stopStreaming()
    }
  }, [])

  async function startHomeCam() {
    try {
      setError('')
      setStatus('移대찓??沅뚰븳???붿껌?섎뒗 以묒엯?덈떎...')

      const mediaStream = await navigator.mediaDevices.getUserMedia({
        video: {
          facingMode: 'environment',
          width: { ideal: 1280 },
          height: { ideal: 720 },
        },
        audio: true,
      })

      streamRef.current = mediaStream

      if (videoRef.current) {
        videoRef.current.srcObject = mediaStream
      }

      setStatus('?쇱씠釉??몄뀡???앹꽦?섎뒗 以묒엯?덈떎...')

      const session = await createLiveSession({
        camera_name: '?대????덉틺',
      })

      setSessionId(session.sessionId)

      const wsUrl = buildLiveWebSocketUrl(session.sessionId, 'host')
      const socket = new WebSocket(wsUrl)
      socketRef.current = socket

      socket.onopen = () => {
        setStatus('?덉틺???쒖옉?섏뿀?듬땲?? ?쒖껌???곌껐??湲곕떎由щ뒗 以묒엯?덈떎.')
        setIsStreaming(true)
        stopRequestedRef.current = false

        if (analysisEnabled) {
          startRealtimeAnalysisLoop()
        }
      }

      socket.onmessage = async (event) => {
        const message = JSON.parse(event.data)

        if (message.type === 'viewer-connected' || message.type === 'viewer-ready') {
          await createOfferForViewer()
          return
        }

        if (message.type === 'answer') {
          if (peerRef.current) {
            await peerRef.current.setRemoteDescription(
              new RTCSessionDescription(message.answer)
            )
            setStatus('?쒖껌?먯? ?곌껐?섏뿀?듬땲??')
          }
          return
        }

        if (message.type === 'candidate') {
          if (peerRef.current && message.candidate) {
            await peerRef.current.addIceCandidate(
              new RTCIceCandidate(message.candidate)
            )
          }
        }

        if (message.type === 'viewer-disconnected') {
          setStatus('?쒖껌???곌껐??醫낅즺?섏뿀?듬땲?? ?ㅼ떆 ?곌껐??湲곕떎由щ뒗 以묒엯?덈떎.')
          closePeer()
        }
      }

      socket.onerror = () => {
        setError('WebSocket ?곌껐 以??ㅻ쪟媛 諛쒖깮?덉뒿?덈떎.')
        setStatus('?쇱씠釉??몄뀡 ?곌껐???ㅽ뙣?덉뒿?덈떎.')
      }

      socket.onclose = () => {
        stopRealtimeAnalysisLoop()

        if (isStreaming) {
          setStatus('?쇱씠釉??몄뀡 ?곌껐??醫낅즺?섏뿀?듬땲??')
        }
      }
    } catch (err) {
      setError(err.message || '?덉틺 ?쒖옉 以??ㅻ쪟媛 諛쒖깮?덉뒿?덈떎.')
      setStatus('idle')
      stopStreaming()
    }
  }

  async function createOfferForViewer() {
    if (!streamRef.current || !socketRef.current) {
      return
    }

    closePeer()

    const peer = new RTCPeerConnection(peerConfig)
    peerRef.current = peer

    streamRef.current.getTracks().forEach((track) => {
      peer.addTrack(track, streamRef.current)
    })

    peer.onicecandidate = (event) => {
      if (event.candidate && socketRef.current?.readyState === WebSocket.OPEN) {
        socketRef.current.send(JSON.stringify({
          type: 'candidate',
          candidate: event.candidate,
        }))
      }
    }

    peer.onconnectionstatechange = () => {
      if (peer.connectionState === 'connected') {
        setStatus('?쒖껌?먯? P2P ?쇱씠釉??곌껐???꾨즺?섏뿀?듬땲??')
      }

      if (
        peer.connectionState === 'failed' ||
        peer.connectionState === 'disconnected'
      ) {
        setStatus('P2P ?곌껐???딄꼈?듬땲?? ?쒖껌???ъ뿰寃곗쓣 湲곕떎由쎈땲??')
      }
    }

    const offer = await peer.createOffer()
    await peer.setLocalDescription(offer)

    socketRef.current.send(JSON.stringify({
      type: 'offer',
      offer,
    }))

    setStatus('?쒖껌?먯뿉寃??쇱씠釉??곌껐 ?붿껌??蹂대깉?듬땲??')
  }

  function startRealtimeAnalysisLoop() {
    if (analysisTimerRef.current) {
      return
    }

    stopRequestedRef.current = false
    setAnalysisStatus('5珥??⑥쐞 ?ㅼ떆媛?遺꾩꽍???쒖옉?덉뒿?덈떎.')

    runAnalysisOnce()

    analysisTimerRef.current = window.setInterval(() => {
      runAnalysisOnce()
    }, ANALYSIS_INTERVAL_MS)
  }

  function stopRealtimeAnalysisLoop() {
    stopRequestedRef.current = true
    analysisRunningRef.current = false

    if (analysisTimerRef.current) {
      window.clearInterval(analysisTimerRef.current)
      analysisTimerRef.current = null
    }

    setAnalysisStatus('遺꾩꽍??以묒??섏뿀?듬땲??')
  }

  async function runAnalysisOnce() {
    if (!analysisEnabled || stopRequestedRef.current) {
      return
    }

    if (analysisRunningRef.current) {
      return
    }

    if (!streamRef.current) {
      return
    }

    try {
      analysisRunningRef.current = true
      setAnalysisStatus('5珥??ㅻ뵒?ㅼ? ?꾩옱 ?꾨젅?꾩쓣 ?섏쭛?섎뒗 以묒엯?덈떎...')

      const [audioFile, frameFile] = await Promise.all([
        recordAudioClipAsWav(streamRef.current, ANALYSIS_INTERVAL_MS),
        captureCurrentFrame(),
      ])

      if (!audioFile && !frameFile) {
        setAnalysisStatus('遺꾩꽍???꾨젅???먮뒗 ?ㅻ뵒?ㅺ? ?놁뒿?덈떎.')
        return
      }

      setAnalysisStatus('遺꾩꽍 ?쒕쾭濡??꾩넚 以묒엯?덈떎...')

      const queued = await requestMultimodalInference({
        audioFile,
        frameFiles: frameFile ? [frameFile] : [],
        capturedAt: new Date().toISOString(),
        frameRate: 1,
        durationSeconds: ANALYSIS_INTERVAL_MS / 1000,
      })

      if (!queued.requestId) {
        throw new Error('遺꾩꽍 requestId媛 ?놁뒿?덈떎.')
      }

      setAnalysisStatus('AI 遺꾩꽍 ?묒뾽 泥섎━ 以묒엯?덈떎...')

      const completed = await waitForInferenceCompleted(queued.requestId)

      setLatestAnalysis(completed.result)
      setAnalysisCount((prev) => prev + 1)
      setAnalysisStatus('理쒓렐 遺꾩꽍 ?꾨즺: ' + toUserFriendlyEmotion(completed.result?.emotion))
    } catch (err) {
      setAnalysisStatus(err.message || '?ㅼ떆媛?遺꾩꽍 ?붿껌 以??ㅻ쪟媛 諛쒖깮?덉뒿?덈떎.')
    } finally {
      analysisRunningRef.current = false
    }
  }

  async function recordAudioClipAsWav(mediaStream, durationMs) {
    const audioTracks = mediaStream.getAudioTracks()

    if (!audioTracks || audioTracks.length === 0) {
      return null
    }

    const AudioContextClass = window.AudioContext || window.webkitAudioContext

    if (!AudioContextClass) {
      return null
    }

    const audioContext = new AudioContextClass()
    await audioContext.resume().catch(() => {})

    const source = audioContext.createMediaStreamSource(new MediaStream(audioTracks))
    const processor = audioContext.createScriptProcessor(4096, 1, 1)
    const chunks = []

    processor.onaudioprocess = (event) => {
      const input = event.inputBuffer.getChannelData(0)
      chunks.push(new Float32Array(input))
    }

    source.connect(processor)
    processor.connect(audioContext.destination)

    await sleep(durationMs)

    try {
      processor.disconnect()
      source.disconnect()
    } catch {
      // ignore
    }

    const originalSampleRate = audioContext.sampleRate

    await audioContext.close().catch(() => {})

    if (chunks.length === 0) {
      return null
    }

    const merged = mergeFloat32Arrays(chunks)
    const resampled = resampleFloat32(merged, originalSampleRate, AUDIO_SAMPLE_RATE)
    const wavBuffer = encodeWav(resampled, AUDIO_SAMPLE_RATE)
    const wavBlob = new Blob([wavBuffer], { type: 'audio/wav' })

    return new File(
      [wavBlob],
      'live_audio_' + Date.now() + '.wav',
      { type: 'audio/wav' }
    )
  }

  async function captureCurrentFrame() {
    const video = videoRef.current

    if (!video || !video.videoWidth || !video.videoHeight) {
      return null
    }

    const canvas = document.createElement('canvas')
    const maxWidth = 640
    const scale = Math.min(1, maxWidth / video.videoWidth)

    canvas.width = Math.round(video.videoWidth * scale)
    canvas.height = Math.round(video.videoHeight * scale)

    const context = canvas.getContext('2d')

    if (!context) {
      return null
    }

    context.drawImage(video, 0, 0, canvas.width, canvas.height)

    const blob = await new Promise((resolve) => {
      canvas.toBlob(resolve, 'image/jpeg', 0.8)
    })

    if (!blob) {
      return null
    }

    return new File(
      [blob],
      'live_frame_' + Date.now() + '.jpg',
      { type: 'image/jpeg' }
    )
  }

  function closePeer() {
    if (peerRef.current) {
      peerRef.current.close()
      peerRef.current = null
    }
  }

  function stopStreaming() {
    stopRealtimeAnalysisLoop()
    closePeer()

    if (socketRef.current) {
      socketRef.current.close()
      socketRef.current = null
    }

    if (streamRef.current) {
      streamRef.current.getTracks().forEach((track) => track.stop())
      streamRef.current = null
    }

    if (videoRef.current) {
      videoRef.current.srcObject = null
    }

    setIsStreaming(false)
    setSessionId('')
    setStatus('idle')
  }

  return (
    <main className='px-5 py-6'>
      <Header title='?대????덉틺' subtitle='??湲곌린瑜??꾩떆 ?덉틺?쇰줈 ?ъ슜?⑸땲??' />

      <section className='mb-5 overflow-hidden rounded-[32px] border border-slate-700/70 bg-slate-900 shadow-card'>
        <div className='relative h-[520px] bg-black'>
          <video
            ref={videoRef}
            autoPlay
            muted
            playsInline
            className='h-full w-full object-cover'
          />

          {!isStreaming && (
            <div className='absolute inset-0 flex flex-col items-center justify-center bg-slate-950 text-center'>
              <div className='mb-4 flex h-20 w-20 items-center justify-center rounded-full bg-blue-400/15 text-blue-200'>
                <Camera size={38} />
              </div>
              <p className='text-lg font-bold'>?덉틺 ?湲?以?/p>
              <p className='mt-2 text-sm text-slate-400'>
                ?쒖옉 踰꾪듉???꾨Ⅴ硫?移대찓?쇱? 留덉씠??沅뚰븳???붿껌?⑸땲??
              </p>
            </div>
          )}

          {isStreaming && (
            <div className='absolute left-4 top-4 flex items-center gap-2 rounded-full bg-rose-500/90 px-3 py-1 text-xs font-bold text-white'>
              <Radio size={14} />
              LIVE
            </div>
          )}
        </div>

        <div className='p-5'>
          <p className='text-sm leading-6 text-slate-300'>
            {status === 'idle' ? '?덉틺 ?쒖옉 踰꾪듉???뚮윭 ?쇱씠釉??몄뀡???앹꽦?섏꽭??' : status}
          </p>

          {sessionId && (
            <p className='mt-2 break-all rounded-2xl bg-slate-800 p-3 text-xs text-slate-400'>
              Session ID: {sessionId}
            </p>
          )}

          {error && (
            <p className='mt-3 rounded-2xl bg-rose-400/10 p-3 text-sm text-rose-300'>
              {error}
            </p>
          )}

          <div className='mt-4 rounded-2xl bg-slate-950/50 p-4'>
            <label className='flex items-center justify-between gap-4'>
              <div>
                <p className='text-sm font-semibold text-blue-200'>?ㅼ떆媛?AI 遺꾩꽍</p>
                <p className='mt-1 text-xs leading-5 text-slate-400'>
                  ?덉틺 ?ㅽ뻾 以?5珥덈쭏???꾨젅?꾧낵 WAV ?ㅻ뵒?ㅻ? 遺꾩꽍?⑸땲??
                </p>
              </div>

              <input
                type='checkbox'
                checked={analysisEnabled}
                onChange={(event) => {
                  const checked = event.target.checked
                  setAnalysisEnabled(checked)

                  if (!checked) {
                    stopRealtimeAnalysisLoop()
                  } else if (isStreaming && streamRef.current) {
                    startRealtimeAnalysisLoop()
                  }
                }}
                className='h-5 w-5'
              />
            </label>
          </div>

          <button
            type='button'
            onClick={isStreaming ? stopStreaming : startHomeCam}
            className='mt-4 flex w-full items-center justify-center gap-2 rounded-2xl bg-blue-500 py-3 text-sm font-bold text-white transition hover:bg-blue-400'
          >
            {isStreaming ? <Square size={18} /> : <Video size={18} />}
            {isStreaming ? '?덉틺 以묒?' : '?덉틺 ?쒖옉?섍린'}
          </button>
        </div>
      </section>

      <Card className='mb-5'>
        <div className='mb-3 flex items-center gap-3'>
          <div className='flex h-11 w-11 items-center justify-center rounded-2xl bg-blue-400/15 text-blue-200'>
            <Activity size={22} />
          </div>
          <div>
            <p className='text-sm font-semibold text-blue-200'>?ㅼ떆媛?遺꾩꽍 ?곹깭</p>
            <p className='mt-1 text-xs text-slate-400'>珥?遺꾩꽍 ?붿껌 {analysisCount}??/p>
          </div>
        </div>

        <p className='rounded-2xl bg-slate-950/50 p-3 text-sm leading-6 text-slate-300'>
          {analysisStatus}
        </p>

        {latestAnalysis && (
          <div className='mt-4 rounded-2xl bg-emerald-400/10 p-4'>
            <p className='text-xs font-semibold text-emerald-200'>理쒓렐 AI 遺꾩꽍 寃곌낵</p>
            <p className='mt-2 text-xl font-bold text-white'>
              {toUserFriendlyEmotion(latestAnalysis.emotion)}
            </p>
            <p className='mt-1 text-sm text-slate-300'>
              理쒖쥌 ?뺣쪧 {Math.round((latestAnalysis.confidence || 0) * 100)}%
            </p>

            {latestAnalysis.topPredictions?.length > 0 && (
              <div className='mt-3 grid grid-cols-2 gap-2'>
                {latestAnalysis.topPredictions.slice(0, 2).map((item, index) => (
                  <div
                    key={item.emotion + index}
                    className='rounded-2xl bg-slate-950/60 p-3'
                  >
                    <p className='text-xs text-blue-200'>TOP {index + 1}</p>
                    <p className='mt-1 text-sm font-semibold text-white'>
                      {toUserFriendlyEmotion(item.emotion)}
                    </p>
                    <p className='mt-1 text-lg text-white'>
                      {Math.round((item.confidence || 0) * 100)}%
                    </p>
                  </div>
                ))}
              </div>
            )}
          </div>
        )}
      </Card>

      <Card>
        <p className='text-sm font-semibold text-blue-200'>?쒖뿰 ?덈궡</p>
        <p className='mt-2 text-sm leading-6 text-slate-400'>
          ???붾㈃? 怨듦린怨??대??곗뿉???댁뼱?먭퀬, ?명듃遺곸뿉?쒕뒗 ?쇱씠釉??쇰뱶 ??뿉???대떦 ?몄뀡???좏깮?섎㈃ ?⑸땲??
          ?ㅼ떆媛?AI 遺꾩꽍? ???대??곗뿉??5珥??⑥쐞濡?湲곗〈 遺꾩꽍 API???붿껌?⑸땲??
        </p>
      </Card>
    </main>
  )
}

async function waitForInferenceCompleted(requestId) {
  const maxAttempts = 30
  const intervalMs = 1000

  for (let attempt = 0; attempt < maxAttempts; attempt += 1) {
    const status = await getInferenceStatus(requestId)

    if (status.status === 'completed') {
      return getInferenceResult(requestId)
    }

    if (status.status === 'failed') {
      throw new Error(status.message || '遺꾩꽍 ?묒뾽???ㅽ뙣?덉뒿?덈떎.')
    }

    await sleep(intervalMs)
  }

  throw new Error('遺꾩꽍 ?묒뾽 ?쒓컙??珥덇낵?섏뿀?듬땲??')
}

function calculateDbfsMetrics(samples) {
  if (!samples || samples.length === 0) {
    return {
      rmsDbfs: -120,
      peakDbfs: -120,
      quietAudio: true,
    }
  }

  let sumSquares = 0
  let peak = 0

  for (let index = 0; index < samples.length; index += 1) {
    const value = Math.abs(samples[index])
    sumSquares += value * value

    if (value > peak) {
      peak = value
    }
  }

  const rms = Math.sqrt(sumSquares / samples.length)
  const rmsDbfs = linearToDbfs(rms)
  const peakDbfs = linearToDbfs(peak)

  return {
    rmsDbfs,
    peakDbfs,
    quietAudio: rmsDbfs <= -38 && peakDbfs <= -25,
  }
}

function linearToDbfs(value) {
  const safeValue = Math.max(Number(value) || 0, 0.000001)
  return Math.round(20 * Math.log10(safeValue) * 10) / 10
}
function mergeFloat32Arrays(chunks) {
  const totalLength = chunks.reduce((sum, chunk) => sum + chunk.length, 0)
  const result = new Float32Array(totalLength)

  let offset = 0

  chunks.forEach((chunk) => {
    result.set(chunk, offset)
    offset += chunk.length
  })

  return result
}

function resampleFloat32(input, inputSampleRate, outputSampleRate) {
  if (inputSampleRate === outputSampleRate) {
    return input
  }

  const ratio = inputSampleRate / outputSampleRate
  const outputLength = Math.round(input.length / ratio)
  const output = new Float32Array(outputLength)

  for (let i = 0; i < outputLength; i += 1) {
    const sourceIndex = i * ratio
    const leftIndex = Math.floor(sourceIndex)
    const rightIndex = Math.min(leftIndex + 1, input.length - 1)
    const weight = sourceIndex - leftIndex

    output[i] = input[leftIndex] * (1 - weight) + input[rightIndex] * weight
  }

  return output
}

function encodeWav(samples, sampleRate) {
  const buffer = new ArrayBuffer(44 + samples.length * 2)
  const view = new DataView(buffer)

  writeString(view, 0, 'RIFF')
  view.setUint32(4, 36 + samples.length * 2, true)
  writeString(view, 8, 'WAVE')
  writeString(view, 12, 'fmt ')
  view.setUint32(16, 16, true)
  view.setUint16(20, 1, true)
  view.setUint16(22, 1, true)
  view.setUint32(24, sampleRate, true)
  view.setUint32(28, sampleRate * 2, true)
  view.setUint16(32, 2, true)
  view.setUint16(34, 16, true)
  writeString(view, 36, 'data')
  view.setUint32(40, samples.length * 2, true)

  floatTo16BitPCM(view, 44, samples)

  return buffer
}

function floatTo16BitPCM(view, offset, input) {
  for (let i = 0; i < input.length; i += 1) {
    const sample = Math.max(-1, Math.min(1, input[i]))
    const value = sample < 0 ? sample * 0x8000 : sample * 0x7fff
    view.setInt16(offset, value, true)
    offset += 2
  }
}

function writeString(view, offset, value) {
  for (let i = 0; i < value.length; i += 1) {
    view.setUint8(offset + i, value.charCodeAt(i))
  }
}

function toUserFriendlyEmotion(value) {
  if (!value) return '遺꾩꽍 以?

  const mapping = {
    諛곌퀬?? '諛곌퀬?뚯슂',
    ?좎??? '?좎???,
    ?쇨낀?? '?좎???,
    遺덊렪?? '遺덊렪?댁슂',
    '?덉젙 ?곹깭': '愿쒖갖?꾩슂',
    ?덉젙?곹깭: '愿쒖갖?꾩슂',
  }

  return mapping[value] || value
}

function sleep(ms) {
  return new Promise((resolve) => {
    setTimeout(resolve, ms)
  })
}

export default CameraHostPage
